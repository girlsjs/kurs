let shelf = {
  name: 'Moja półka',
  authors: [
    {
      name: 'Douglas Adams',
      nationality: 'british',
      books: [
        { title: 'Hitchickers Guide to Galaxy', year: 1979 },
        { title: 'Restaurant at the end of Galaxy', year: 1980 },
        { title: 'Life, the Universe and Everything Else', year: 1982 },
      ]
    },
    {
      name: 'Terry Pratchett',
      nationality: 'british',
      books: [
        { title: 'Nomów księga wyjścia', year: 1989 },
        { title: 'Nomów księga kopania', year: 1990 },
        { title: 'Nomów księga odlotu', year: 1990 },
      ]
    }
  ]
}
