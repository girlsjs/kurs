let buttons = [];
let image = document.querySelector('#placeholder');
let currentIndex = 0;
let next = document.querySelector('#next');
let prev = document.querySelector('#prev');
let nav = document.querySelector('nav > ul');

function nextImage() {
  currentIndex++;
  changeImage(images[currentIndex], image);
  selectButton(currentIndex, buttons);
}

function prevImage() {
  currentIndex--;
  changeImage(images[currentIndex], image);
  selectButton(currentIndex, buttons);
}

for (i = 0; i < images.length; i++) {
  btn = createButton();
  btn.id = 'button' + i;
  btn.addEventListener('click', () => {
    changeImage(images[i], image);
    selectButton(i);
    currentIndex = i;
  });
  nav.appendChild(btn);
}

next.addEventListener('click', nextImage);
prev.addEventListener('click', prevImage);

changeImage(images[currentIndex], image);
selectButton(currentIndex, buttons);
