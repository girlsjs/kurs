function changeImage(newSrc, imageHandler) {
  imageHandler.src = newSrc;
}

function selectButton(idx, buttons) {
  let selected = document.querySelector('.selected');
  if (selected) {
    selected.classList.remove('selected');
  }
  buttons[idx].classList.add('selected');
}

function createButton() {
  let li = document.createElement('li');
  let btn = document.createElement('button');
  li.appendChild(btn);
  btn.classList.add('pin');
  buttons.push(btn);
  return li;
}
