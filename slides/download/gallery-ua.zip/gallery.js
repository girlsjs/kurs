/* girls.js - Interaktywna Galeria
 * Файл gallery.js
 * Тут будемо писати наш код. 
 */
