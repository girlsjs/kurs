document.querySelector( '#slide5' ).classList.add( 'show' );
document.querySelector( '#slide4' ).classList.add( 'show' );
document.querySelector( '#slide5' ).classList.remove( 'show' );
